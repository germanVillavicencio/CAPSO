﻿namespace AcademiaSoft.CapaDominio.Entidades
{
    public class Docente : Persona
    {
        public Docente() { }

    }
}
